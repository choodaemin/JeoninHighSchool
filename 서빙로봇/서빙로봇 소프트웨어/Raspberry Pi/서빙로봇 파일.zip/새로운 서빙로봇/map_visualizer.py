"""
map_visualizer.py
1280 x 960 대시보드 GUI 및 2D SLAM 점유 격자 지도 시각화 모듈

레이아웃:
  - Total Size: 1280 x 960
  - Left Panel (380 x 960): 서빙로봇 현재 위치 패널, Target X/Y 입력 필드, 주행시작/초기화/비상정지 버튼, 시스템 정보
  - Right Panel (900 x 960): 2D 점유 맵, 로봇 Pose, 7방향 추천 화살표, 목표 과녁 오버레이
"""

import cv2
import numpy as np
import math
from typing import Optional, Tuple, Dict, Any
from mapper import OccupancyMap, CELL_FREE, CELL_WALL, CELL_OBSTACLE, CELL_UNKNOWN
from path_recommender import PathRecommendation, DirectionScore
import config


class MapVisualizer:
    # ── 창 및 패널 규격 ───────────────────────────────────────────────
    WINDOW_WIDTH  = 1280
    WINDOW_HEIGHT = 960

    LEFT_PANEL_W  = 380
    MAP_WIDTH     = 900
    MAP_HEIGHT    = 960

    # ── 색상 팔레트 (Ultra-Modern Cyberpunk Sleek Dark - BGR) ──────────
    COLOR_BG_DARK       = (14, 18, 24)       # 패널 배경 (딥 미드나이트)
    COLOR_CARD_BG       = (24, 30, 40)       # 카드 배경 (슬릭 챠콜)
    COLOR_CARD_BORDER   = (55, 70, 95)       # 카드 테두리 (네온 스트라이프)
    COLOR_TEXT_WHITE    = (250, 252, 255)    # 주 텍스트
    COLOR_TEXT_GRAY     = (170, 182, 198)    # 보조 텍스트
    COLOR_TEXT_DIM      = (115, 128, 145)    # 희미한 텍스트

    # 울트라 모던 버튼 색상
    COLOR_BTN_START     = (40, 160, 70)      # 주행 시작 (네온 에메랄드)
    COLOR_BTN_START_HOV = (60, 210, 95)
    COLOR_BTN_RESET     = (180, 125, 30)     # 초기화 (앰버 골드)
    COLOR_BTN_RESET_HOV = (210, 155, 45)
    COLOR_BTN_STOP      = (35, 35, 210)      # 비상정지 (네온 크림슨)
    COLOR_BTN_STOP_HOV  = (55, 55, 240)
    COLOR_BTN_QUIT      = (75, 25, 125)      # 시스템 종료 (다크 메탈릭 시클라멘)
    COLOR_BTN_QUIT_HOV  = (130, 40, 180)

    # 입력창
    COLOR_INPUT_BG      = (18, 22, 30)
    COLOR_INPUT_BORDER  = (65, 80, 105)
    COLOR_INPUT_ACTIVE  = (240, 190, 40)     # 활성화 시 네온 시안/골드

    # 맵 셀 색상 (슬릭 네온 SLAM 맵)
    COLOR_UNKNOWN       = (18, 20, 26)       # 미지 영역
    COLOR_FREE          = (225, 230, 235)    # 빈 공간 (밝은 슬레이트 세라믹)
    COLOR_WALL          = (95, 102, 115)     # 벽
    COLOR_OBSTACLE      = (30, 110, 245)     # 장애물 (코랄 네온)
    COLOR_ROBOT         = (240, 200, 30)     # 로봇 위치 (네온 시안)
    COLOR_BEST_DIR      = (80, 235, 120)     # 최적 방향 (일렉트릭 링)
    COLOR_BAD_DIR       = (45, 45, 220)      # 위험 방향 (빨강)
    COLOR_GRID          = (36, 42, 54)       # 격자선
    COLOR_AXIS          = (125, 135, 150)    # 축
    COLOR_LABEL         = (210, 215, 225)    # 레이블

    TICK_INTERVAL_M = 1.0

    # ── UI 요소 ROI (Region of Interest) 정의 (X, Y, W, H) ─────────────
    ROI_INPUT_X       = (30, 275, 150, 42)
    ROI_INPUT_Y       = (200, 275, 150, 42)
    ROI_BTN_START     = (30, 395, 320, 38)
    ROI_BTN_ALIGN_HEAD= (30, 440, 320, 38)   # [🧭 ALIGN HEADING] 0°/360° 정렬 버튼!
    ROI_BTN_RESET     = (30, 485, 320, 36)
    ROI_BTN_STOP      = (30, 528, 320, 38)
    ROI_BTN_QUIT      = (30, 572, 320, 38)   # [EXIT / QUIT SYSTEM] 종료 버튼!

    def __init__(self, occ_map: OccupancyMap):
        self.occ_map = occ_map
        # 900x960 맵 영역에 맞춰 셀 당 픽셀 수 계산
        self.px_per_cell = min(self.MAP_WIDTH / occ_map.width_cells, self.MAP_HEIGHT / occ_map.height_cells)

    def render(
        self,
        recommendation: Optional[PathRecommendation] = None,
        fps: float = 0.0,
        lidar_points: int = 0,
        input_target_x_str: str = "0.00",
        input_target_y_str: str = "0.00",
        active_input: Optional[str] = None,  # 'x' or 'y' or None
        is_driving: bool = False,
        is_emergency: bool = False,
        status_msg: str = "READY",
    ) -> np.ndarray:
        """1280x960 대시보드 렌더링"""
        # 전체 캔버스 생성
        canvas = np.full((self.WINDOW_HEIGHT, self.WINDOW_WIDTH, 3), self.COLOR_BG_DARK, dtype=np.uint8)

        # 1. 왼쪽 대시보드 패널 렌더링 (0 ~ 380)
        left_panel = self._render_left_panel(
            recommendation=recommendation,
            fps=fps,
            lidar_points=lidar_points,
            input_target_x_str=input_target_x_str,
            input_target_y_str=input_target_y_str,
            active_input=active_input,
            is_driving=is_driving,
            is_emergency=is_emergency,
            status_msg=status_msg,
        )
        canvas[0:960, 0:380] = left_panel

        # 2. 오른쪽 2D SLAM 맵 렌더링 (380 ~ 1280)
        map_canvas = self._render_map_area(recommendation)
        canvas[0:960, 380:1280] = map_canvas

        # 구분선 (Left | Right)
        cv2.line(canvas, (380, 0), (380, 960), (60, 70, 85), 2)

        return canvas

    # ── Left Panel 렌더링 ─────────────────────────────────────────────
    def _render_left_panel(
        self,
        recommendation: Optional[PathRecommendation],
        fps: float,
        lidar_points: int,
        input_target_x_str: str,
        input_target_y_str: str,
        active_input: Optional[str],
        is_driving: bool,
        is_emergency: bool,
        status_msg: str,
    ) -> np.ndarray:
        panel = np.full((self.WINDOW_HEIGHT, self.LEFT_PANEL_W, 3), self.COLOR_BG_DARK, dtype=np.uint8)
        font = cv2.FONT_HERSHEY_SIMPLEX

        # Title Header
        cv2.rectangle(panel, (0, 0), (self.LEFT_PANEL_W, 60), (28, 34, 44), -1)
        cv2.putText(panel, "SERVING ROBOT CONTROL", (20, 38), font, 0.65, (255, 255, 255), 2, cv2.LINE_AA)
        cv2.line(panel, (0, 60), (self.LEFT_PANEL_W, 60), (55, 65, 80), 1)

        # ─────────────────────────────────────────────────────────────
        # ─────────────────────────────────────────────────────────────
        # Card 1: 📍 현재 서빙로봇 실시간 위치 좌표 (Real-time Robot Pose & Target)
        # ─────────────────────────────────────────────────────────────
        self._draw_card(panel, (15, 70, 350, 145), "REAL-TIME ROBOT POSE & TARGET")
        
        robot_x = recommendation.robot_x if recommendation else 0.0
        robot_y = recommendation.robot_y if recommendation else 0.0
        robot_deg = recommendation.robot_heading_deg if recommendation else 0.0

        # 실시간 위치 좌표 박스 컨테이너
        cv2.rectangle(panel, (25, 102), (340, 158), (18, 22, 30), -1)
        cv2.rectangle(panel, (25, 102), (340, 158), (50, 65, 85), 1)

        # X, Y 좌표 (크고 밝은 폰트로 선명하게 시각화)
        x_str = f"X: {robot_x:+.2f} m"
        y_str = f"Y: {robot_y:+.2f} m"
        cv2.putText(panel, x_str, (33, 128), font, 0.62, (80, 235, 255), 2, cv2.LINE_AA)
        cv2.putText(panel, y_str, (185, 128), font, 0.62, (80, 235, 255), 2, cv2.LINE_AA)

        # 헤딩 각도
        heading_str = f"Heading: {robot_deg:+.1f} deg"
        cv2.putText(panel, heading_str, (33, 150), font, 0.42, (240, 200, 40), 1, cv2.LINE_AA)

        # 목표 좌표 및 남은 거리 표시
        if recommendation and recommendation.target_x is not None:
            tgt_dist = recommendation.dist_to_goal_m if recommendation.dist_to_goal_m is not None else 0.0
            tgt_str = f"Target: ({recommendation.target_x:.2f}, {recommendation.target_y:.2f})m | Dist: {tgt_dist:.2f}m"
            cv2.putText(panel, tgt_str, (25, 178), font, 0.38, (180, 220, 255), 1, cv2.LINE_AA)

        # 상태 배지
        if is_emergency:
            state_text = "EMERGENCY STOP"
            badge_color = (40, 40, 230)
        elif is_driving:
            state_text = "NAVIGATING TO TARGET..."
            badge_color = (45, 180, 75)
        else:
            state_text = "IDLE / STOPPED"
            badge_color = (180, 140, 40)

        cv2.rectangle(panel, (25, 188), (340, 208), badge_color, -1)
        cv2.putText(panel, f"STATE: {state_text}", (35, 203), font, 0.40, (255, 255, 255), 1, cv2.LINE_AA)

        # ─────────────────────────────────────────────────────────────
        # Card 2: 🎯 목표 좌표 입력 (Target Input X, Y)
        # ─────────────────────────────────────────────────────────────
        self._draw_card(panel, (15, 225, 350, 135), "TARGET COORDINATES INPUT")

        # X 입력창
        ix, iy, iw, ih = self.ROI_INPUT_X
        border_x = self.COLOR_INPUT_ACTIVE if active_input == 'x' else self.COLOR_INPUT_BORDER
        cv2.putText(panel, "Target X (m):", (ix, iy - 8), font, 0.42, self.COLOR_TEXT_GRAY, 1, cv2.LINE_AA)
        cv2.rectangle(panel, (ix, iy), (ix + iw, iy + ih), self.COLOR_INPUT_BG, -1)
        cv2.rectangle(panel, (ix, iy), (ix + iw, iy + ih), border_x, 2 if active_input == 'x' else 1)
        disp_x = input_target_x_str + ("|" if active_input == 'x' else "")
        cv2.putText(panel, disp_x, (ix + 12, iy + 28), font, 0.60, self.COLOR_TEXT_WHITE, 2, cv2.LINE_AA)

        # Y 입력창
        iy_y = self.ROI_INPUT_Y[1]
        border_y = self.COLOR_INPUT_ACTIVE if active_input == 'y' else self.COLOR_INPUT_BORDER
        cv2.putText(panel, "Target Y (m):", (self.ROI_INPUT_Y[0], iy_y - 8), font, 0.42, self.COLOR_TEXT_GRAY, 1, cv2.LINE_AA)
        cv2.rectangle(panel, (self.ROI_INPUT_Y[0], iy_y), (self.ROI_INPUT_Y[0] + iw, iy_y + ih), self.COLOR_INPUT_BG, -1)
        cv2.rectangle(panel, (self.ROI_INPUT_Y[0], iy_y), (self.ROI_INPUT_Y[0] + iw, iy_y + ih), border_y, 2 if active_input == 'y' else 1)
        disp_y = input_target_y_str + ("|" if active_input == 'y' else "")
        cv2.putText(panel, disp_y, (self.ROI_INPUT_Y[0] + 12, iy_y + 28), font, 0.60, self.COLOR_TEXT_WHITE, 2, cv2.LINE_AA)

        # 입력 설명 팁
        cv2.putText(panel, "* Click box to type values", (30, 348), font, 0.38, self.COLOR_TEXT_DIM, 1, cv2.LINE_AA)

        # ─────────────────────────────────────────────────────────────
        # Card 3: 🕹️ 제어 버튼 (Control Actions)
        # ─────────────────────────────────────────────────────────────
        self._draw_card(panel, (15, 365, 350, 255), "SYSTEM CONTROL PANEL")

        # 1) 주행 시작 버튼
        bx, by, bw, bh = self.ROI_BTN_START
        btn_start_bg = (40, 150, 65) if not is_driving else (25, 90, 45)
        btn_start_border = (80, 235, 120) if not is_driving else (60, 160, 90)
        cv2.rectangle(panel, (bx, by), (bx + bw, by + bh), btn_start_bg, -1)
        cv2.rectangle(panel, (bx, by), (bx + bw, by + bh), btn_start_border, 2)
        cv2.putText(panel, "▶ START DRIVE (RUN)", (bx + 52, by + 25), font, 0.50, (255, 255, 255), 2, cv2.LINE_AA)

        # 2) [신규] 헤딩 0°/360° 정렬 버튼
        ax, ay, aw, ah = self.ROI_BTN_ALIGN_HEAD
        cv2.rectangle(panel, (ax, ay), (ax + aw, ay + ah), (30, 100, 180), -1)
        cv2.rectangle(panel, (ax, ay), (ax + aw, ay + ah), (50, 160, 255), 1)
        cv2.putText(panel, "🧭 ALIGN HEADING (0/360)", (ax + 35, ay + 25), font, 0.48, (255, 255, 255), 1, cv2.LINE_AA)

        # 3) 초기화 버튼
        rx, ry, rw, rh = self.ROI_BTN_RESET
        cv2.rectangle(panel, (rx, ry), (rx + rw, ry + rh), self.COLOR_BTN_RESET, -1)
        cv2.rectangle(panel, (rx, ry), (rx + rw, ry + rh), (220, 170, 50), 1)
        cv2.putText(panel, "🔄 RESET MAP & POSE", (rx + 52, ry + 24), font, 0.46, (255, 255, 255), 1, cv2.LINE_AA)

        # 4) 비상정지 버튼
        ex, ey, ew, eh = self.ROI_BTN_STOP
        cv2.rectangle(panel, (ex, ey), (ex + ew, ey + eh), self.COLOR_BTN_STOP, -1)
        cv2.rectangle(panel, (ex, ey), (ex + ew, ey + eh), (90, 90, 255), 2)
        cv2.putText(panel, "🚨 EMERGENCY STOP", (ex + 52, ey + 25), font, 0.50, (255, 255, 255), 2, cv2.LINE_AA)

        # 5) 시스템 종료 버튼 (QUIT SYSTEM)
        qx, qy, qw, qh = self.ROI_BTN_QUIT
        cv2.rectangle(panel, (qx, qy), (qx + qw, qy + qh), self.COLOR_BTN_QUIT, -1)
        cv2.rectangle(panel, (qx, qy), (qx + qw, qy + qh), (190, 60, 230), 2)
        cv2.putText(panel, "🛑 QUIT SYSTEM (EXIT)", (qx + 42, qy + 25), font, 0.50, (255, 255, 255), 2, cv2.LINE_AA)

        # ─────────────────────────────────────────────────────────────
        # Card 4: 📊 10° 단위 세분화 경로 분석 & 시스템 상태
        # ─────────────────────────────────────────────────────────────
        self._draw_card(panel, (15, 630, 350, 315), "10-DEG STEP PATH & STATS")

        if recommendation:
            stuck_txt = " [STUCK]" if recommendation.is_stuck else ""
            cv2.putText(panel, f"Recommendation: {recommendation.best_label}{stuck_txt}",
                        (30, 660), font, 0.48, (80, 230, 100), 1, cv2.LINE_AA)

            # 상세 사유 줄바꿈 표시
            reason_lines = self._wrap_text(recommendation.reason, max_chars=34)
            for i, line in enumerate(reason_lines):
                cv2.putText(panel, line, (30, 685 + i * 20), font, 0.40, (180, 200, 190), 1, cv2.LINE_AA)

        # 맵 통계
        stats = self.occ_map.stats()
        stat_lines = [
            f"Explored Area: {stats['explored_pct']}%",
            f"Free / Wall / Obst: {stats['free']} / {stats['wall']} / {stats['obstacle']}",
            f"LiDAR Pts: {lidar_points}  |  FPS: {fps:.1f}",
            f"Status Msg: {status_msg}",
        ]
        for i, line in enumerate(stat_lines):
            cv2.putText(panel, line, (30, 755 + i * 22), font, 0.40, self.COLOR_TEXT_GRAY, 1, cv2.LINE_AA)

        # 범례 표시
        cv2.putText(panel, "[ Legend ]", (30, 830), font, 0.42, self.COLOR_TEXT_WHITE, 1, cv2.LINE_AA)
        legend = [
            (self.COLOR_FREE, "Free"),
            (self.COLOR_WALL, "Wall"),
            (self.COLOR_OBSTACLE, "Obstacle"),
            (self.COLOR_ROBOT, "Robot"),
        ]
        lx, ly = 30, 855
        for color, label in legend:
            cv2.rectangle(panel, (lx, ly - 10), (lx + 14, ly + 4), color, -1)
            cv2.putText(panel, label, (lx + 20, ly + 2), font, 0.38, self.COLOR_TEXT_GRAY, 1, cv2.LINE_AA)
            lx += 82

        return panel

    def _draw_card(self, panel: np.ndarray, bbox: Tuple[int, int, int, int], title: str):
        x, y, w, h = bbox
        # 카드 배경
        cv2.rectangle(panel, (x, y), (x + w, y + h), self.COLOR_CARD_BG, -1)
        cv2.rectangle(panel, (x, y), (x + w, y + h), self.COLOR_CARD_BORDER, 1)
        # 타이틀 상단 모던 헤더 바
        cv2.rectangle(panel, (x + 1, y + 1), (x + w - 1, y + 26), (32, 40, 54), -1)
        # 좌측 네온 시안 Accent 포인트
        cv2.rectangle(panel, (x + 8, y + 6), (x + 12, y + 20), (240, 190, 40), -1)
        cv2.putText(panel, title, (x + 18, y + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.44, self.COLOR_TEXT_WHITE, 1, cv2.LINE_AA)
        cv2.line(panel, (x + 1, y + 26), (x + w - 1, y + 26), (60, 75, 95), 1)

    # ── Right Panel (900x960 2D Map) 렌더링 ───────────────────────────
    def _render_map_area(self, recommendation: Optional[PathRecommendation]) -> np.ndarray:
        MW, MH = self.MAP_WIDTH, self.MAP_HEIGHT
        px = self.px_per_cell
        canvas = np.full((MH, MW, 3), self.COLOR_BG_DARK, dtype=np.uint8)

        grid = self.occ_map.grid
        H, W = grid.shape

        # 중앙 정렬을 위한 오프셋
        offset_x = int((MW - W * px) / 2)
        offset_y = int((MH - H * px) / 2)

        cell_px = max(1, int(px))
        for row in range(H):
            for col in range(W):
                val = grid[row, col]
                if val == CELL_UNKNOWN:
                    color = self.COLOR_UNKNOWN
                elif val < CELL_WALL:
                    color = self.COLOR_FREE
                elif val < CELL_OBSTACLE:
                    color = self.COLOR_WALL
                elif val == 0.6:
                    color = (200, 220, 255)
                else:
                    color = self.COLOR_OBSTACLE

                y1 = offset_y + int(row * px)
                x1 = offset_x + int(col * px)
                y2 = min(y1 + cell_px, MH)
                x2 = min(x1 + cell_px, MW)
                if x1 < MW and y1 < MH:
                    canvas[y1:y2, x1:x2] = color

        # 격자선 (1m 간격)
        grid_m = 1.0
        grid_cells = max(1, int(grid_m / self.occ_map.resolution))
        for i in range(0, W, grid_cells):
            x = offset_x + int(i * px)
            cv2.line(canvas, (x, offset_y), (x, offset_y + int(H * px)), self.COLOR_GRID, 1)
        for j in range(0, H, grid_cells):
            y = offset_y + int(j * px)
            cv2.line(canvas, (offset_x, y), (offset_x + int(W * px), y), self.COLOR_GRID, 1)

        # 축 표시 (로봇 0,0 기준)
        rx = offset_x + int(self.occ_map.robot_col * px + px / 2)
        ry = offset_y + int(self.occ_map.robot_row * px + px / 2)

        cv2.line(canvas, (offset_x, ry), (offset_x + int(W * px), ry), self.COLOR_AXIS, 1)
        cv2.line(canvas, (rx, offset_y), (rx, offset_y + int(H * px)), self.COLOR_AXIS, 1)

        # 눈금 숫자 표시
        font = cv2.FONT_HERSHEY_SIMPLEX
        tick_cells = max(1, int(self.TICK_INTERVAL_M / self.occ_map.resolution))
        for col in range(0, W, tick_cells):
            x = offset_x + int(col * px + px / 2)
            cv2.line(canvas, (x, ry - 5), (x, ry + 5), self.COLOR_AXIS, 1)
            if col == self.occ_map.robot_col:
                continue
            x_m = (col - self.occ_map.robot_col) * self.occ_map.resolution
            label = f"{x_m:.0f}" if abs(x_m - round(x_m)) < 1e-6 else f"{x_m:.1f}"
            cv2.putText(canvas, label, (x - 12, ry + 22), font, 0.35, self.COLOR_LABEL, 1, cv2.LINE_AA)

        for row in range(0, H, tick_cells):
            y = offset_y + int(row * px + px / 2)
            cv2.line(canvas, (rx - 5, y), (rx + 5, y), self.COLOR_AXIS, 1)
            if row == self.occ_map.robot_row:
                continue
            y_m = (self.occ_map.robot_row - row) * self.occ_map.resolution
            label = f"{y_m:.0f}" if abs(y_m - round(y_m)) < 1e-6 else f"{y_m:.1f}"
            cv2.putText(canvas, label, (rx + 10, y + 4), font, 0.35, self.COLOR_LABEL, 1, cv2.LINE_AA)

        # 로봇 원형 표식
        cv2.circle(canvas, (rx, ry), 10, self.COLOR_ROBOT, -1, cv2.LINE_AA)
        cv2.circle(canvas, (rx, ry), 10, (255, 255, 255), 2, cv2.LINE_AA)
        cv2.putText(canvas, "ROBOT (0,0)", (rx + 14, ry - 12), font, 0.42, (255, 255, 255), 1, cv2.LINE_AA)

        # 위험/경고/안전 구역 동심원
        for zone_m, color in [
            (config.ZONE_DANGER_M,  (40,  40, 220)),
            (config.ZONE_WARNING_M, (40, 160, 230)),
            (config.ZONE_SAFE_M,    (60, 210,  60)),
        ]:
            r_px = int(zone_m / self.occ_map.resolution * px)
            cv2.circle(canvas, (rx, ry), r_px, color, 1, cv2.LINE_AA)

        # 경로 추천 및 목표 오버레이 그리기
        if recommendation:
            self._draw_recommendation_overlay(canvas, recommendation, rx, ry, offset_x, offset_y, px)

        return canvas

    def _draw_recommendation_overlay(
        self, canvas: np.ndarray, rec: PathRecommendation, rx: int, ry: int, offset_x: int, offset_y: int, px: float
    ):
        font = cv2.FONT_HERSHEY_SIMPLEX

        # 목표 지점 표시
        if rec.target_x is not None and rec.target_y is not None:
            rel_tx = rec.target_x - rec.robot_x
            rel_ty = rec.target_y - rec.robot_y

            row_t, col_t = self.occ_map.world_to_cell(rel_tx, rel_ty)
            tx = offset_x + int(col_t * px + px / 2)
            ty = offset_y + int(row_t * px + px / 2)

            color_target = (0, 215, 255) if not rec.is_goal_reached else (50, 255, 50)
            cv2.circle(canvas, (tx, ty), 14, color_target, 2, cv2.LINE_AA)
            cv2.circle(canvas, (tx, ty), 5, color_target, -1, cv2.LINE_AA)
            cv2.line(canvas, (tx - 18, ty), (tx + 18, ty), color_target, 1, cv2.LINE_AA)
            cv2.line(canvas, (tx, ty - 18), (tx, ty + 18), color_target, 1, cv2.LINE_AA)

            # 로봇 ~ 목표 가이드 라인
            cv2.line(canvas, (rx, ry), (tx, ty), (0, 190, 255), 1, cv2.LINE_AA)
            label_goal = f"TARGET ({rec.target_x:.1f}, {rec.target_y:.1f})"
            cv2.putText(canvas, label_goal, (tx + 16, ty + 4), font, 0.45, color_target, 1, cv2.LINE_AA)

        # 2D 지도 상단 HUD 배너: 실시간 좌표 (X, Y, Heading) 오버레이
        hud_bg_color = (20, 26, 36)
        hud_border = (60, 75, 95)
        cv2.rectangle(canvas, (20, 15), (480, 55), hud_bg_color, -1)
        cv2.rectangle(canvas, (20, 15), (480, 55), hud_border, 1)
        cv2.rectangle(canvas, (25, 20), (29, 50), (240, 190, 40), -1)
        
        hud_str1 = f"REAL-TIME POSE: X={rec.robot_x:+.2f}m, Y={rec.robot_y:+.2f}m, Head={rec.robot_heading_deg:+.1f} deg"
        cv2.putText(canvas, hud_str1, (38, 40), font, 0.45, (80, 235, 255), 1, cv2.LINE_AA)

        # 19방향 추천 화살표
        for ds in rec.scores:
            rad = math.radians(ds.angle_deg)
            length = int(ds.clearance_m / self.occ_map.resolution * px * 0.85)
            ex = int(rx + length * math.sin(rad))
            ey = int(ry - length * math.cos(rad))

            if ds.angle_deg == rec.best_angle_deg:
                cv2.arrowedLine(canvas, (rx, ry), (ex, ey), self.COLOR_BEST_DIR, 3, tipLength=0.22, line_type=cv2.LINE_AA)
                cv2.putText(canvas, rec.best_label, (ex + 10, ey - 5), font, 0.55, self.COLOR_BEST_DIR, 2, cv2.LINE_AA)
            else:
                cv2.line(canvas, (rx, ry), (ex, ey), self.COLOR_BAD_DIR, 1, cv2.LINE_AA)

    @staticmethod
    def _wrap_text(text: str, max_chars: int) -> list:
        words = text.split()
        lines = []
        current = ""
        for word in words:
            if len(current) + len(word) + 1 <= max_chars:
                current += (" " if current else "") + word
            else:
                if current:
                    lines.append(current)
                current = word
        if current:
            lines.append(current)
        return lines[:3]