"""
path_recommender.py
하이브리드 7방향 경로 추천 및 BLE 회피 제어 모듈

동작 로직:
  1. 7방향의 스코어링(50x50cm 풋프린트 반영) 분석 결과를 실시간으로 시각화 대시보드에 제공합니다.
  2. 웬만한 상태(평상시)에서는 무조건 직진(best_angle_deg = 0.0)을 유지하며 BLE로 "0"을 송신합니다.
  3. 전방 50cm 이내에 장애물 감지 시 즉시 정지 상태로 천이하며 BLE로 "-1"을 전송합니다.
  4. 정지 상태에서 아두이노로부터 초음파 센서 거리(RIGHT, LEFT) 값을 받아오고, 
     이를 맵핑 데이터(격자 지도 상의 좌/우 clearance)와 복합 계산하여 최적의 회피 방향(오른쪽 90 또는 왼쪽 -90)을 정합니다.
  5. 회피 상태(TURNING)에서 일정 프레임(8프레임) 회피 주행 신호를 송신한 뒤 전방이 확보되면 다시 직진으로 복귀합니다.
"""

import math
import re
import json
from dataclasses import dataclass, field
from typing import List, Tuple, Optional
from mapper import OccupancyMap, CELL_WALL, CELL_OBSTACLE


@dataclass
class DirectionScore:
    angle_deg: float
    score: float
    clearance_m: float
    has_unknown: bool
    label: str


@dataclass
class PathRecommendation:
    best_angle_deg: float
    best_label: str
    reason: str
    scores: List[DirectionScore]
    is_stuck: bool = False
    target_x: Optional[float] = None
    target_y: Optional[float] = None
    target_name: str = ""
    dist_to_goal_m: Optional[float] = None
    goal_rel_angle_deg: Optional[float] = None
    is_goal_reached: bool = False
    robot_x: float = 0.0
    robot_y: float = 0.0
    robot_heading_deg: float = 0.0


class PathRecommender:
    # ── 설정 ─────────────────────────────────────────────────────
    FRONT_STOP_DIST_M = 0.30   # 전방 장애물 감지 기준 거리 (코앞 30cm 이내일 때만 회피)
    ROBOT_HALF_M      = 0.25   # 로봇 몸체 절반 (50cm / 2 = 25cm)
    SAFE_MARGIN_M     = 0.30   # 몸체 반폭 + 안전 여유 (25cm + 5cm)
    MAX_RANGE_M       = 3.0    # 센서 최대 탐색 거리 (m)
    CELL_THRESHOLD    = 0.6    # 충돌 감지 임계점
    STOP_ANGLE        = -1.0   # 정지 신호
    UTURN_ANGLE       = 180.0  # 유턴 신호
    ARRIVE_MARGIN_M   = 0.10   # 목표 도착 판단 오차 거리 (0.10m = 10cm 주변 도달 시 정지)

    # 검사할 10도 단위 세분화 19방향 (각도, 레이블)
    DIRECTIONS = [
        (0,    "Front"),       # 전방
        (10,   "Right-10"),    # 우측 10도
        (20,   "Right-20"),    # 우측 20도
        (30,   "Right-30"),    # 우측 30도
        (40,   "Right-40"),    # 우측 40도
        (50,   "Right-50"),    # 우측 50도
        (60,   "Right-60"),    # 우측 60도
        (70,   "Right-70"),    # 우측 70도
        (80,   "Right-80"),    # 우측 80도
        (90,   "Right-90"),    # 우측 90도 (직각 우회)
        (-10,  "Left-10"),     # 좌측 10도
        (-20,  "Left-20"),     # 좌측 20도
        (-30,  "Left-30"),     # 좌측 30도
        (-40,  "Left-40"),     # 좌측 40도
        (-50,  "Left-50"),     # 좌측 50도
        (-60,  "Left-60"),     # 좌측 60도
        (-70,  "Left-70"),     # 좌측 70도
        (-80,  "Left-80"),     # 좌측 80도
        (-90,  "Left-90"),     # 좌측 90도 (직각 좌회)
    ]

    # BLE 메시지 파싱 정규식: "right, left" 2개 또는 "x, y, heading, right, left" 5개 포맷 통합 지원
    BLE_PATTERN = re.compile(
        r"(?:(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,\s*)?(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)",
    )

    def __init__(self, occ_map: OccupancyMap):
        self.occ_map = occ_map

        # 로봇 몸체 풋프린트 (50cm x 50cm 사각형) 격자 오프셋 사전 계산
        self.footprint_offsets: List[Tuple[int, int]] = []
        self._precompute_footprint()

        # 회피 전용 디귿(ㄷ)자형 초음파 측면 감지 상태 머신
        # ("IDLE" | "AVOID_TURN_90" | "AVOID_PASS_WIDTH" | "AVOID_TURN_FRONT" | "AVOID_PASS_LENGTH")
        self.avoid_state: str = "IDLE"
        self.avoid_side: str = "RIGHT"          # "RIGHT" (+90도 우회전 후 좌측초음파 감시) | "LEFT" (-90도 좌회전 후 우측초음파 감시)
        self.avoid_target_head: Optional[float] = None
        self.avoid_clear_count: int = 0         # 측면 초음파 값 급증(장애물 이탈) 연속 감지 카운트
        self.avoid_step_timeout: int = 0        # 무한 직진 방지 안전 타임아웃
        self.avoid_min_steps: int = 0           # 최소 직진 보장 카운터 (원형/의자 다리 오감지 방지)
        self.avoid_forward_timer: int = 0

        # 상태 머신 (기본 대기 상태: STOPPED -> [주행 시작] 클릭 시 FORWARD 전환)
        self.state = "STOPPED"   # "STOPPED" | "FORWARD" | "TURNING" | "GOAL_REACHED"
        self.aligning_heading: bool = False  # 버튼 클릭 시 0도/360도 1도 단위 정렬 활성화 플래그
        self.turn_angle = 0.0    # 회피 방향 각도
        self.turn_label = ""     # 회피 방향 라벨
        self.turn_timer = 0      # 회피 유지 프레임

        # 목표 좌표 관련 변수
        self.target_x: Optional[float] = None
        self.target_y: Optional[float] = None
        self.target_name: str = ""

        # 주행 시작 시점의 기준 원점 (로봇 전방=+X, 좌측=+Y, 우측=-Y)
        self.origin_x: float = 0.0
        self.origin_y: float = 0.0
        self.origin_heading: float = 0.0

        # 로봇 현재 추적 오도메트리 위치
        self.robot_x: float = 0.0
        self.robot_y: float = 0.0
        self.robot_heading_deg: float = 0.0

        # BLE 수신 데이터 저장 (초기 시작 시 오인 정지/회피 방지를 위해 999.0cm로 초기화)
        self.ble_right_cm = 999.0
        self.ble_left_cm  = 999.0
        self.ble_right_history = []
        self.ble_left_history = []

        # BLE 프로세서 연결
        self.ble = None
        try:
            from BLE_processor import ble_processor
            self.ble = ble_processor()
            self.ble.start()
            print("[PathRecommender] BLE 연결 완료")
        except Exception as e:
            print(f"[PathRecommender] BLE 연결 실패 (단독 모드): {e}")

    # ── 풋프린트 사전 계산 (50cm x 50cm 사각형) ──────────────────
    def _precompute_footprint(self):
        """로봇 50cm x 50cm 사각형 몸체의 격자 오프셋 계산"""
        res = self.occ_map.resolution
        half_cells = int(math.ceil(self.ROBOT_HALF_M / res))
        for dr in range(-half_cells, half_cells + 1):
            for dc in range(-half_cells, half_cells + 1):
                self.footprint_offsets.append((dr, dc))

    # ── "주행 시작" 및 "주행 정지", "헤딩 정렬" 메소드 ───────────────────────
    def start_heading_alignment(self):
        """'헤딩 정렬' 버튼 클릭 시: 0도 또는 360도 중 더 가까운 쪽에 1도 단위로 정렬 시작"""
        self._poll_ble()
        self.aligning_heading = True
        print(f"\n[PathRecommender] [ALIGN] 헤딩 0°/360° 정렬 시작! (현재 헤딩: {self.robot_heading_deg:.1f}°)")

    def start_navigation(self, x_m: float, y_m: float, name: str = "Goal"):
        """'주행 시작': 현재 로봇 위치를 원점(전방=+X, 좌측=+Y, 우측=-Y)으로 정렬하고 목표 주행 개시"""
        self._poll_ble()
        self.aligning_heading = False
        self.origin_x = self.robot_x
        self.origin_y = self.robot_y
        self.origin_heading = self.robot_heading_deg
        self.avoid_state = "IDLE"
        self.avoid_target_head = None
        self.avoid_forward_timer = 0

        self.target_x = float(x_m)
        self.target_y = float(y_m)
        self.target_name = name
        self.state = "FORWARD"
        self.sub_stage = "ALIGN_X"  # 1단계 X축 정렬 -> 2단계 Y축 정렬 순차 주행
        print(f"\n[PathRecommender] [START] 주행 시작! 목표 좌표: ({x_m:.2f}, {y_m:.2f}) [전방=+X, 좌측=+Y, 우측=-Y] (1단계 X축 정렬 시작)")

    def _send_stop_packet(self, reset_odo: bool = False):
        """
        정지 신호를 딕셔너리(JSON) 형태로 BLE 송신합니다.
        - 평상시 (구동 전 / 대기 / 정지): {"S-signal": "STOP", "R-signal": ""}
        - 좌표 초기화 버튼 클릭 시: {"S-signal": "STOP", "R-signal": "RESET_ODO"}
        """
        payload = {
            "S-signal": "STOP",
            "R-signal": "RESET_ODO" if reset_odo else ""
        }
        self._send_ble(json.dumps(payload))

    def stop_navigation(self):
        """'주행 정지': 즉시 주행을 취소하고 정지 신호 {"S-signal":"STOP", "R-signal":""} 전송 및 STOPPED 상태 전환"""
        self.target_x = None
        self.target_y = None
        self.target_name = ""
        self.avoid_state = "IDLE"
        self.avoid_target_head = None
        self.avoid_forward_timer = 0
        self.aligning_heading = False
        self.state = "STOPPED"
        self._send_stop_packet(reset_odo=False)
        print("\n[PathRecommender] [STOP] 주행 정지! (사용자 정지 요청 -> 정지 패킷 {\"S-signal\":\"STOP\", \"R-signal\":\"\"} 전송)")

    def reset_odometry(self):
        """'오도메트리 초기화': 로봇 내부 좌표를 0.0으로 리셋하고 BLE를 통해 {"S-signal":"STOP", "R-signal":"RESET_ODO"} 전송"""
        self.stop_navigation()
        self.robot_x = 0.0
        self.robot_y = 0.0
        self.robot_heading_deg = 0.0
        self.origin_x = 0.0
        self.origin_y = 0.0
        self.origin_heading = 0.0
        self.avoid_state = "IDLE"
        self.avoid_target_head = None
        self.avoid_forward_timer = 0
        self.aligning_heading = False
        self._send_stop_packet(reset_odo=True)
        print("\n[PathRecommender] [RESET] 오도메트리 리셋 신호 {\"S-signal\":\"STOP\", \"R-signal\":\"RESET_ODO\"} BLE 전송 완료")

    def set_target(self, x_m: float, y_m: float, name: str = "Goal"):
        """목표 좌표 설정 호환용 래퍼"""
        self.start_navigation(x_m, y_m, name)

    def clear_target(self):
        """목표 좌표 해제 호환용 래퍼"""
        self.stop_navigation()

    def set_target_goal(self, x_m: float, y_m: float, name: str = "Target"):
        """목표 좌표 호환용 래퍼"""
        self.start_navigation(x_m, y_m, name)

    def clear_target_goal(self):
        """목표 좌표 해제 호환용 래퍼"""
        self.stop_navigation()

    def _compute_goal_vector(self) -> Tuple[Optional[float], Optional[float], Optional[float]]:
        """
        주행 시작 시점 원점 기준 상대 위치에서 목표 (target_x, target_y)까지의
        (남은거리m, 로봇 상대 목표 각도deg, 목표 절대 각도deg) 계산.
        축 정의: 전방=+X(0도), 좌측=+Y(-90도), 우측=-Y(+90도), 후방=-X(180도)
        """
        if self.target_x is None or self.target_y is None:
            return None, None, None

        # 원점 기준 상대 현재 위치 (전방=+X, 좌측=+Y, 우측=-Y)
        rel_x = self.robot_x - self.origin_x
        rel_y = self.robot_y - self.origin_y

        dx = self.target_x - rel_x
        dy = self.target_y - rel_y
        dist_m = math.hypot(dx, dy)

        # dx:전방(+X), dy:좌측(+Y)/우측(-Y) -> atan2(-dy, dx) => 전방=0도, 우측=+90도, 좌측=-90도, 후방=180도
        goal_global_deg = math.degrees(math.atan2(-dy, dx))

        # 로봇 헤딩 차이 보정
        rel_angle_deg = goal_global_deg - (self.robot_heading_deg - self.origin_heading)
        rel_angle_deg = (rel_angle_deg + 180.0) % 360.0 - 180.0

        return dist_m, rel_angle_deg, goal_global_deg

    def _get_heading_alignment_steering(self, target_heading_deg: float) -> Tuple[float, str]:
        """
        목표 절대 헤딩 각도(target_heading_deg, 전방 기준 0도, 우측 +90, 좌측 -90, 후방 180)와
        현재 로봇 헤딩(self.robot_heading_deg) 간의 오차를 계산하여
        15도 이내로 정렬되면 직진(0.0, 'Front'),
        15도 초과 오차 시 부드러운 10도 단위 회전 명령을 반환합니다.
        """
        current_head = (self.robot_heading_deg - self.origin_heading + 180.0) % 360.0 - 180.0
        head_err = (target_heading_deg - current_head + 180.0) % 360.0 - 180.0

        # 헤딩 오차가 15도 이내이면 정렬 완료 -> 시원하게 직진!
        if abs(head_err) <= 15.0:
            return 0.0, "Front"

        # 헤딩 오차가 클 때는 10도 단위로 부드럽게 회전 (20도 ~ 90도 범위 클리핑)
        if head_err > 0:
            turn_deg = min(90.0, max(20.0, round(head_err / 10.0) * 10.0))
            return turn_deg, f"Right-{int(turn_deg)}"
        else:
            turn_deg = max(-90.0, min(-20.0, round(head_err / 10.0) * 10.0))
            return turn_deg, f"Left-{int(abs(turn_deg))}"

    def _get_zero_alignment_steering_1deg(self) -> Tuple[float, str, float, bool]:
        """
        '헤딩 정렬' 버튼 클릭 시, BLE를 통해 들어오는 현재 헤딩값을
        0과 360 중 더 가까운 쪽에 1도 단위 정밀 각도로 맞춥니다.

        반환값:
            (chosen_angle, chosen_label, target_head, is_aligned)
        """
        curr_head = (self.robot_heading_deg % 360.0 + 360.0) % 360.0  # 0.0 ~ 360.0 정규화

        diff_0 = abs(curr_head - 0.0)
        diff_360 = abs(curr_head - 360.0)

        if diff_0 <= diff_360:
            target_head = 0.0
            head_err = (0.0 - curr_head + 180.0) % 360.0 - 180.0
        else:
            target_head = 360.0
            head_err = (360.0 - curr_head + 180.0) % 360.0 - 180.0

        # 오차 1도 이내이면 정렬 완료!
        if abs(head_err) <= 1.0:
            return 0.0, "Front", target_head, True

        # 1도 단위 정밀 조향 (오차 각도를 1도 단위로 정수 클리핑 송신)
        turn_deg = float(max(-90, min(90, int(round(head_err)))))
        label = f"Right-{int(turn_deg)}" if turn_deg > 0 else f"Left-{int(abs(turn_deg))}"
        return turn_deg, label, target_head, False

    # ── BLE 메시지 수신 및 파싱 (실시간 x, y, heading 수신) ──────────────────
    def _poll_ble(self):
        """
        BLE 수신 데이터를 파싱하여 실시간 x, y, heading 좌표 및 초음파 센서값을 갱신합니다.
        지원 포맷:
        1. 5개 인자: "x, y, heading, right, left" (예: "0.25, 1.10, 0.0, 100, 80")
        2. 3개 인자: "x, y, heading" (예: "0.25, 1.10, 15.0")
        3. 2개 인자: "x, y" (예: "0.25, 1.10")
        4. Key-Value 형식: "X:0.25 Y:1.10 H:0.0" 또는 "x=0.25, y=1.10"
        5. 초음파 전용: "RIGHT: 50 LEFT: 80"
        """
        if self.ble is None:
            return

        # 큐에 쌓인 메시지를 모두 읽어서 가장 최신 값만 사용
        latest = None
        while True:
            msg = self.ble.get_response()
            if msg is None:
                break
            latest = msg

        if latest is None:
            return

        try:
            if latest.startswith("__"):
                return

            text = latest.strip()

            # 1. Key-Value 형태 파싱 (X:, Y:, H:, R:, L:)
            kx = re.search(r"[xX]\s*[:=]\s*(-?\d+(?:\.\d+)?)", text)
            ky = re.search(r"[yY]\s*[:=]\s*(-?\d+(?:\.\d+)?)", text)
            kh = re.search(r"(?:[hH]|heading)\s*[:=]\s*(-?\d+(?:\.\d+)?)", text, re.IGNORECASE)
            kr = re.search(r"(?:[rR]|right)\s*[:=]\s*(\d+(?:\.\d+)?)", text, re.IGNORECASE)
            kl = re.search(r"(?:[lL]|left)\s*[:=]\s*(\d+(?:\.\d+)?)", text, re.IGNORECASE)

            if kx and ky:
                self.robot_x = float(kx.group(1))
                self.robot_y = float(ky.group(1))
                if kh:
                    self.robot_heading_deg = float(kh.group(1))
                if kr and kl:
                    self._update_ultrasonic(float(kr.group(1)), float(kl.group(1)))
                print(f"[BLE 수신] 원본: '{text}' -> 파싱: (X:{self.robot_x:+.2f}m, Y:{self.robot_y:+.2f}m, Head:{self.robot_heading_deg:+.1f}deg)")
                return

            # 2. 쉼표(,) 및 공백 기반 숫자 분리 파싱
            parts = [p.strip() for p in text.replace(",", " ").split() if p.strip()]
            nums = []
            for p in parts:
                try:
                    nums.append(float(p))
                except ValueError:
                    pass

            if len(nums) >= 5:
                # [x값, y값, 헤딩, 오른쪽초음파, 왼쪽초음파]
                self.robot_x = nums[0]
                self.robot_y = nums[1]
                self.robot_heading_deg = nums[2]
                self._update_ultrasonic(nums[3], nums[4])
            elif len(nums) == 4:
                # [x, y, right, left]
                self.robot_x = nums[0]
                self.robot_y = nums[1]
                self._update_ultrasonic(nums[2], nums[3])
            elif len(nums) == 3:
                # [x값, y값, 헤딩]
                self.robot_x = nums[0]
                self.robot_y = nums[1]
                self.robot_heading_deg = nums[2]
            elif len(nums) == 2:
                # 2개 인자: 값이 둘 다 20 미만이면 x, y 우선 판정
                if abs(nums[0]) <= 20.0 and abs(nums[1]) <= 20.0 and (isinstance(nums[0], float) or isinstance(nums[1], float)):
                    self.robot_x = nums[0]
                    self.robot_y = nums[1]
                else:
                    self._update_ultrasonic(nums[0], nums[1])
            
            print(f"[BLE 수신] 원본: '{text}' -> 파싱: (X:{self.robot_x:+.2f}m, Y:{self.robot_y:+.2f}m, Head:{self.robot_heading_deg:+.1f}deg, R:{self.ble_right_cm:.1f}cm, L:{self.ble_left_cm:.1f}cm)")
        except Exception as e:
            print(f"[PathRecommender] BLE 파싱 예외 발생 ({latest}): {e}")

    def _update_ultrasonic(self, raw_right: float, raw_left: float):
        """초음파 노이즈 필터링 (최근 3개 값의 중간값 필터)"""
        self.ble_right_history.append(raw_right)
        self.ble_left_history.append(raw_left)
        if len(self.ble_right_history) > 3:
            self.ble_right_history.pop(0)
        if len(self.ble_left_history) > 3:
            self.ble_left_history.pop(0)

        self.ble_right_cm = sorted(self.ble_right_history)[len(self.ble_right_history) // 2]
        self.ble_left_cm  = sorted(self.ble_left_history)[len(self.ble_left_history) // 2]

    # ── BLE 전송 헬퍼 ────────────────────────────────────────────
    def _send_ble(self, s_signal: str, r_signal: str = ""):
        """
        BLE를 통해 JSON 딕셔너리 패킷 {"S-signal": ..., "R-signal": ...} 형태로 Arduino에 전송
        - 주행 중 추천 방향: {"S-signal": "0", "R-signal": ""} / {"S-signal": "90", "R-signal": ""} 등
        - 정지/도착/대기: {"S-signal": "STOP", "R-signal": ""}
        - 좌표 초기화: {"S-signal": "STOP", "R-signal": "RESET_ODO"}
        """
        if self.ble is not None:
            try:
                payload = {
                    "S-signal": str(s_signal),
                    "R-signal": str(r_signal)
                }
                self.ble.send(json.dumps(payload))
            except Exception as e:
                print(f"[BLE] 전송 오류: {e}")

    def _send_stop_packet(self, reset_odo: bool = False):
        """정지/초기화 딕셔너리 패킷 송신 래퍼"""
        self._send_ble("STOP", "RESET_ODO" if reset_odo else "")

    # ── 50cm x 50cm 사각형 풋프린트를 고려한 여유 거리 측정 ───
    def _measure_clearance_with_footprint(self, angle_deg: float) -> float:
        """
        로봇의 현재 헤딩(robot_heading_deg)을 반영하여
        특정 로컬 방향 각도로 로봇 몸체(50cm x 50cm)를 고려한 안전 거리를 레이 마칭으로 측정합니다.
        """
        curr_rel_head = getattr(self, "robot_heading_deg", 0.0) - getattr(self, "origin_heading", 0.0)
        global_deg = angle_deg + curr_rel_head
        rad = math.radians(global_deg)
        step_m = self.occ_map.resolution
        clearance = 0.0

        dist = 0.05
        while dist <= self.MAX_RANGE_M:
            x_m = dist * math.sin(rad)
            y_m = dist * math.cos(rad)
            row_c, col_c = self.occ_map.world_to_cell(x_m, y_m)

            if not self.occ_map.in_bounds(row_c, col_c):
                break

            hit = False
            obstacle_pixels = 0
            for dr, dc in self.footprint_offsets:
                r = row_c + dr
                c = col_c + dc
                if not self.occ_map.in_bounds(r, c):
                    hit = True
                    break
                cell = float(self.occ_map.grid[r, c])
                if cell >= self.CELL_THRESHOLD:
                    obstacle_pixels += 1
                    if obstacle_pixels >= 3:
                        hit = True
                        break

            if hit:
                if dist <= 0.05:
                    clearance = 0.0
                break

            clearance = dist
            dist += step_m

        return clearance

    # ── 메인 추천 엔진 ───────────────────────────────────────────
    def recommend(self) -> PathRecommendation:
        """
        하이브리드 동작 로직:
        1. 목표 좌표가 지정된 경우 목표 지향성 스코어링 및 거리 계산 연동.
        2. 목표지점 25cm 이내 도달 시 정지 신호 및 GOAL_REACHED 상태 전환.
        3. 평상시(FORWARD)에는 목표 방향 또는 안전 방향으로 주행.
        4. 전방 80cm 이내 장애물 감지 시 정지(STOPPED) 및 초음파+맵 복합 회피.
        """
        # BLE 최신 수신 값 및 위치 파싱
        self._poll_ble()

        # 목표 좌표 벡터 계산
        dist_m, goal_rel_angle, goal_global_angle = self._compute_goal_vector()
        has_goal = (dist_m is not None and goal_rel_angle is not None)

        # 1. 19방향 스코어링 수행 (직진 우대 가중치 및 목표 지향성 반영)
        scores: List[DirectionScore] = []
        for angle_deg, label in self.DIRECTIONS:
            clearance = self._measure_clearance_with_footprint(angle_deg)
            if has_goal:
                angle_diff = abs((angle_deg - goal_rel_angle + 180.0) % 360.0 - 180.0)
                # 남은 거리가 가까울수록(0.8m 이내) 목표 지향 가중치를 대폭 상향하여 도착지로 확실히 빨려들어가 안착
                dist_weight = 6.0 if (dist_m and dist_m < 0.8) else 4.0
                goal_alignment_bonus = max(0.0, 1.0 - angle_diff / 180.0) * dist_weight
                straight_bonus = 2.0 if angle_deg == 0 else 0.0
                score = clearance * 2.0 + goal_alignment_bonus + straight_bonus
            else:
                forward_bonus = max(0.0, 1.0 - abs(angle_deg) / 180.0) * 1.5
                straight_bonus = 2.5 if angle_deg == 0 else 0.0
                score = clearance * 2.0 + forward_bonus + straight_bonus

            scores.append(DirectionScore(
                angle_deg   = angle_deg,
                score       = score,
                clearance_m = clearance,
                has_unknown = False,
                label       = label,
            ))

        # 전방 0도 안전 거리
        front_clearance = scores[0].clearance_m

        # ── 0. 목표 도착 여부 최우선 판단 ──
        if has_goal and dist_m <= self.ARRIVE_MARGIN_M:
            self.state = "GOAL_REACHED"
            self.aligning_heading = False
            self._send_stop_packet(reset_odo=False)
            return PathRecommendation(
                best_angle_deg=self.STOP_ANGLE,
                best_label="Arrived",
                reason=f"목표 {self.target_name} 도착 완료! ({dist_m:.2f}m 이내)",
                scores=scores,
                is_stuck=False,
                target_x=self.target_x,
                target_y=self.target_y,
                target_name=self.target_name,
                dist_to_goal_m=dist_m,
                goal_rel_angle_deg=goal_rel_angle,
                is_goal_reached=True,
                robot_x=self.robot_x,
                robot_y=self.robot_y,
                robot_heading_deg=self.robot_heading_deg,
            )

        # ── 1. FORWARD 상태 ──
        if self.state == "FORWARD":
            if has_goal:
                rel_x = self.robot_x - self.origin_x
                rel_y = self.robot_y - self.origin_y
                dx = self.target_x - rel_x
                dy = self.target_y - rel_y

                # 최종 도착 체크 (X, Y 종합 거리 오차 0.10m 이내)
                dist_to_goal = math.hypot(dx, dy)
                if dist_to_goal <= self.ARRIVE_MARGIN_M:
                    self.state = "GOAL_REACHED"
                    self.avoid_state = "IDLE"
                    self.aligning_heading = False
                    self._send_stop_packet(reset_odo=False)
                    return PathRecommendation(
                        best_angle_deg=self.STOP_ANGLE,
                        best_label="Arrived",
                        reason=f"목표 {self.target_name} 도착 완료! (오차 {dist_to_goal:.2f}m)",
                        scores=scores,
                        is_stuck=False,
                        target_x=self.target_x,
                        target_y=self.target_y,
                        target_name=self.target_name,
                        dist_to_goal_m=dist_to_goal,
                        goal_rel_angle_deg=goal_rel_angle,
                        is_goal_reached=True,
                        robot_x=self.robot_x,
                        robot_y=self.robot_y,
                        robot_heading_deg=self.robot_heading_deg,
                    )

                # ─────────────────────────────────────────────────────────
                # [회피 1순위] 디귿(ㄷ)자형 초음파 측면 감지 4단계 완전 회피 머신 (3대 안전 강화)
                # ─────────────────────────────────────────────────────────
                # 1단계: 직각 90도 선회
                if getattr(self, "avoid_state", "IDLE") == "AVOID_TURN_90":
                    current_head = (self.robot_heading_deg - self.origin_heading + 180.0) % 360.0 - 180.0
                    head_err = (self.avoid_target_head - current_head + 180.0) % 360.0 - 180.0

                    if abs(head_err) > 15.0:
                        chosen_angle, chosen_label = self._get_heading_alignment_steering(self.avoid_target_head)
                        reason_msg = f"[회피 1단계: 90도 선회] {self.avoid_side} 90도({self.avoid_target_head:+.0f}°) 회전 중 (오차:{head_err:+.1f}°, 조향:{chosen_label})"
                    else:
                        # 90도 선회 완료 시점
                        # [안전 강화 3] 회전 직후 측면 초음파에 장애물이 이미 없으면 (사람이 지나감) -> 즉시 0도 복귀!
                        init_side_dist = self.ble_left_cm if self.avoid_side == "RIGHT" else self.ble_right_cm
                        if init_side_dist >= 80.0:
                            self.avoid_state = "AVOID_TURN_FRONT"
                            self.avoid_target_head = 0.0
                            self.avoid_clear_count = 0
                            self.avoid_step_timeout = 50
                            self.avoid_min_steps = 0
                            chosen_angle, chosen_label = self._get_heading_alignment_steering(0.0)
                            reason_msg = f"[회피 스마트 복귀] 장애물이 이미 사라짐 (측면:{init_side_dist:.1f}cm) -> 즉시 0도 복귀 개시"
                        else:
                            # 2단계 가로 폭 직진 및 측면 초음파 감시 시작!
                            self.avoid_state = "AVOID_PASS_WIDTH"
                            self.avoid_clear_count = 0
                            self.avoid_step_timeout = 50
                            self.avoid_min_steps = 5  # [안전 강화 2] 최소 5프레임(15~20cm) 직진 보장
                            chosen_angle = 0.0
                            chosen_label = "Front"
                            reason_msg = f"[회피 2단계: 가로 폭 통과] 선회 완료 -> 직진하며 측면 초음파 감시 개시"

                    self._send_ble(str(int(chosen_angle)))
                    return PathRecommendation(
                        best_angle_deg=chosen_angle,
                        best_label=chosen_label,
                        reason=reason_msg,
                        scores=scores,
                        is_stuck=False,
                        target_x=self.target_x,
                        target_y=self.target_y,
                        target_name=self.target_name,
                        dist_to_goal_m=dist_m,
                        goal_rel_angle_deg=goal_rel_angle,
                        is_goal_reached=False,
                        robot_x=self.robot_x,
                        robot_y=self.robot_y,
                        robot_heading_deg=self.robot_heading_deg,
                    )

                # 2단계: 가로 폭 직진 & 측면 초음파 감시 (모퉁이 벗어남 감지)
                elif getattr(self, "avoid_state", "IDLE") == "AVOID_PASS_WIDTH":
                    chosen_angle = 0.0
                    chosen_label = "Front"
                    self.avoid_step_timeout -= 1
                    self.avoid_min_steps -= 1

                    side_dist = self.ble_left_cm if self.avoid_side == "RIGHT" else self.ble_right_cm

                    # [안전 강화 2] 최소 직진 거리(5프레임)를 만족한 후에만 clearance 판정
                    if self.avoid_min_steps <= 0:
                        if side_dist >= 45.0:
                            self.avoid_clear_count += 1
                        else:
                            self.avoid_clear_count = 0
                    else:
                        self.avoid_clear_count = 0

                    if (self.avoid_clear_count >= 2 and self.avoid_min_steps <= 0) or self.avoid_step_timeout <= 0:
                        self.avoid_state = "AVOID_TURN_FRONT"
                        self.avoid_target_head = 0.0
                        self.avoid_clear_count = 0
                        self.avoid_step_timeout = 50
                        self.avoid_min_steps = 0
                        chosen_angle, chosen_label = self._get_heading_alignment_steering(0.0)
                        reason_msg = f"[회피 3단계: 전방 정렬] 장애물 가로 폭 통과 완료 (측면:{side_dist:.1f}cm) -> 헤딩 0도 회전 개시"
                    else:
                        reason_msg = f"[회피 2단계: 가로 폭 통과] 장애물 옆 직진 통과 중 (측면 초음파:{side_dist:.1f}cm, 최소잔여:{max(0, self.avoid_min_steps)})"

                    self._send_ble(str(int(chosen_angle)))
                    return PathRecommendation(
                        best_angle_deg=chosen_angle,
                        best_label=chosen_label,
                        reason=reason_msg,
                        scores=scores,
                        is_stuck=False,
                        target_x=self.target_x,
                        target_y=self.target_y,
                        target_name=self.target_name,
                        dist_to_goal_m=dist_m,
                        goal_rel_angle_deg=goal_rel_angle,
                        is_goal_reached=False,
                        robot_x=self.robot_x,
                        robot_y=self.robot_y,
                        robot_heading_deg=self.robot_heading_deg,
                    )

                # 3단계: 헤딩 0도(전방 직진 방향) 선회
                elif getattr(self, "avoid_state", "IDLE") == "AVOID_TURN_FRONT":
                    current_head = (self.robot_heading_deg - self.origin_heading + 180.0) % 360.0 - 180.0
                    head_err = (0.0 - current_head + 180.0) % 360.0 - 180.0

                    if abs(head_err) > 15.0:
                        chosen_angle, chosen_label = self._get_heading_alignment_steering(0.0)
                        reason_msg = f"[회피 3단계: 전방 정렬] 헤딩 0도 정렬 중 (오차:{head_err:+.1f}°, 조향:{chosen_label})"
                    else:
                        self.avoid_state = "AVOID_PASS_LENGTH"
                        self.avoid_clear_count = 0
                        self.avoid_step_timeout = 50
                        self.avoid_min_steps = 5  # [안전 강화 2] 세로 길이 최소 5프레임 직진 보장
                        chosen_angle = 0.0
                        chosen_label = "Front"
                        reason_msg = f"[회피 4단계: 세로 길이 추월] 전방 정렬 완료 -> 직진하며 장애물 추월 감시"

                    self._send_ble(str(int(chosen_angle)))
                    return PathRecommendation(
                        best_angle_deg=chosen_angle,
                        best_label=chosen_label,
                        reason=reason_msg,
                        scores=scores,
                        is_stuck=False,
                        target_x=self.target_x,
                        target_y=self.target_y,
                        target_name=self.target_name,
                        dist_to_goal_m=dist_m,
                        goal_rel_angle_deg=goal_rel_angle,
                        is_goal_reached=False,
                        robot_x=self.robot_x,
                        robot_y=self.robot_y,
                        robot_heading_deg=self.robot_heading_deg,
                    )

                # 4단계: 세로 길이 직진 & 측면 초음파 감시 (장애물 완전 추월 감지)
                elif getattr(self, "avoid_state", "IDLE") == "AVOID_PASS_LENGTH":
                    chosen_angle = 0.0
                    chosen_label = "Front"
                    self.avoid_step_timeout -= 1
                    self.avoid_min_steps -= 1

                    side_dist = self.ble_left_cm if self.avoid_side == "RIGHT" else self.ble_right_cm

                    # [안전 강화 2] 최소 직진 거리 만족 후 clearance 판정
                    if self.avoid_min_steps <= 0:
                        if side_dist >= 45.0:
                            self.avoid_clear_count += 1
                        else:
                            self.avoid_clear_count = 0
                    else:
                        self.avoid_clear_count = 0

                    if (self.avoid_clear_count >= 2 and self.avoid_min_steps <= 0) or self.avoid_step_timeout <= 0:
                        self.avoid_state = "IDLE"
                        self.avoid_target_head = None
                        self.avoid_clear_count = 0
                        reason_msg = f"[회피 완료] 장애물 완전 추월 완료 (측면:{side_dist:.1f}cm) -> 현재 위치 기준 목적지 주행 복귀"
                    else:
                        reason_msg = f"[회피 4단계: 세로 길이 추월] 장애물 몸통 추월 직진 통과 중 (측면 초음파:{side_dist:.1f}cm, 최소잔여:{max(0, self.avoid_min_steps)})"

                    self._send_ble(str(int(chosen_angle)))
                    return PathRecommendation(
                        best_angle_deg=chosen_angle,
                        best_label=chosen_label,
                        reason=reason_msg,
                        scores=scores,
                        is_stuck=False,
                        target_x=self.target_x,
                        target_y=self.target_y,
                        target_name=self.target_name,
                        dist_to_goal_m=dist_m,
                        goal_rel_angle_deg=goal_rel_angle,
                        is_goal_reached=False,
                        robot_x=self.robot_x,
                        robot_y=self.robot_y,
                        robot_heading_deg=self.robot_heading_deg,
                    )

                # ─────────────────────────────────────────────────────────
                # [일반 주행] 목표 지향 2단계 순차 이동 (X -> Y)
                # ─────────────────────────────────────────────────────────
                if not hasattr(self, "sub_stage") or self.sub_stage is None:
                    self.sub_stage = "ALIGN_X"

                # 1단계 vs 2단계 목표 헤딩 결정 (전방=+X(0도), 좌측=+Y(-90도), 우측=-Y(+90도), 후방=-X(180도))
                if self.sub_stage == "ALIGN_X":
                    if abs(dx) > 0.10:
                        target_head = 0.0 if dx > 0 else 180.0
                        stage_name = "1단계 X정렬"
                    else:
                        self.sub_stage = "ALIGN_Y"
                        target_head = -90.0 if dy >= 0 else 90.0
                        stage_name = "2단계 Y정렬 전환"
                elif self.sub_stage == "ALIGN_Y":
                    if abs(dy) > 0.10:
                        target_head = -90.0 if dy >= 0 else 90.0
                        stage_name = "2단계 Y정렬"
                    else:
                        if abs(dx) > 0.10:
                            self.sub_stage = "ALIGN_X"
                            target_head = 0.0 if dx > 0 else 180.0
                            stage_name = "1단계 X재정렬"
                        else:
                            # X, Y 모두 0.10m 이내 도착
                            self.state = "GOAL_REACHED"
                            self.avoid_state = "IDLE"
                            self.aligning_heading = False
                            self._send_stop_packet(reset_odo=False)
                            return PathRecommendation(
                                best_angle_deg=self.STOP_ANGLE,
                                best_label="Arrived",
                                reason=f"목표 {self.target_name} 도착 완료! (오차 {dist_to_goal:.2f}m)",
                                scores=scores,
                                is_stuck=False,
                                target_x=self.target_x,
                                target_y=self.target_y,
                                target_name=self.target_name,
                                dist_to_goal_m=dist_to_goal,
                                goal_rel_angle_deg=goal_rel_angle,
                                is_goal_reached=True,
                                robot_x=self.robot_x,
                                robot_y=self.robot_y,
                                robot_heading_deg=self.robot_heading_deg,
                            )

                # 현재 로봇 헤딩과 목표 각도 간의 오차 계산
                current_head = (self.robot_heading_deg - self.origin_heading + 180.0) % 360.0 - 180.0
                head_err = (target_head - current_head + 180.0) % 360.0 - 180.0
                is_turning = abs(head_err) > 15.0

                # ─────────────────────────────────────────────────────────
                # [규칙] 제자리에서 턴을 할 때는 장애물 인식을 통한 방향 추천을 하지 않음!
                # ─────────────────────────────────────────────────────────
                if is_turning:
                    chosen_angle, chosen_label = self._get_heading_alignment_steering(target_head)
                    reason_msg = f"[{stage_name} 턴 중] 목표각({target_head:+.0f}°) 회전 정렬 중 (오차:{head_err:+.1f}°, 조향:{chosen_label})"
                    self._send_ble(str(int(chosen_angle)))
                    return PathRecommendation(
                        best_angle_deg=chosen_angle,
                        best_label=chosen_label,
                        reason=reason_msg,
                        scores=scores,
                        is_stuck=False,
                        target_x=self.target_x,
                        target_y=self.target_y,
                        target_name=self.target_name,
                        dist_to_goal_m=dist_m,
                        goal_rel_angle_deg=goal_rel_angle,
                        is_goal_reached=False,
                        robot_x=self.robot_x,
                        robot_y=self.robot_y,
                        robot_heading_deg=self.robot_heading_deg,
                    )

                # ─────────────────────────────────────────────────────────
                # [직진 전진 상태] 턴이 완료되어 직진할 때만 장애물 감지 시 디귿자형 회피 시작!
                # ─────────────────────────────────────────────────────────
                if front_clearance < self.FRONT_STOP_DIST_M:
                    # 초음파 센서 값이 더 큰 쪽(더 넓게 트인 쪽)으로 회피 방향 결정
                    if abs(self.ble_right_cm - self.ble_left_cm) >= 5.0:
                        prefer_right = self.ble_right_cm > self.ble_left_cm
                    else:
                        # 초음파 센서 값이 거의 대등할 때만 라이다 여유 공간 비교
                        right_scores = [s for s in scores if s.angle_deg > 0]
                        left_scores  = [s for s in scores if s.angle_deg < 0]
                        right_lidar_clearance = max([s.clearance_m for s in right_scores], default=0.0)
                        left_lidar_clearance  = max([s.clearance_m for s in left_scores], default=0.0)
                        prefer_right = right_lidar_clearance >= left_lidar_clearance

                    self.avoid_side = "RIGHT" if prefer_right else "LEFT"
                    self.avoid_target_head = 90.0 if prefer_right else -90.0
                    self.avoid_state = "AVOID_TURN_90"
                    self.avoid_clear_count = 0
                    self.avoid_step_timeout = 50

                    chosen_angle, chosen_label = self._get_heading_alignment_steering(self.avoid_target_head)
                    self._send_ble(str(int(chosen_angle)))
                    return PathRecommendation(
                        best_angle_deg=chosen_angle,
                        best_label=chosen_label,
                        reason=f"전방 장애물 ({front_clearance:.2f}m) 감지 -> 초음파(우:{self.ble_right_cm:.1f}cm, 좌:{self.ble_left_cm:.1f}cm) 기준 {'우측' if prefer_right else '좌측'} 90도 회피 시작",
                        scores=scores,
                        is_stuck=False,
                        target_x=self.target_x,
                        target_y=self.target_y,
                        target_name=self.target_name,
                        dist_to_goal_m=dist_m,
                        goal_rel_angle_deg=goal_rel_angle,
                        is_goal_reached=False,
                        robot_x=self.robot_x,
                        robot_y=self.robot_y,
                        robot_heading_deg=self.robot_heading_deg,
                    )

                # 초음파 센서 근접 보정
                if self.ble_right_cm < 25.0 and self.ble_left_cm < 25.0:
                    best_s = max(scores, key=lambda s: s.clearance_m)
                    chosen_angle = best_s.angle_deg if best_s.clearance_m > 0.2 else 90.0
                    self._send_ble(str(int(chosen_angle)))
                    return PathRecommendation(
                        best_angle_deg=chosen_angle,
                        best_label=best_s.label if best_s.clearance_m > 0.2 else "Right-90",
                        reason=f"양측 초음파 25cm 미만 (R:{self.ble_right_cm:.1f}cm L:{self.ble_left_cm:.1f}cm) -> {chosen_angle:+.0f}도 긴급 회피 조향",
                        scores=scores,
                        is_stuck=False,
                        target_x=self.target_x,
                        target_y=self.target_y,
                        target_name=self.target_name,
                        dist_to_goal_m=dist_m,
                        goal_rel_angle_deg=goal_rel_angle,
                        is_goal_reached=False,
                        robot_x=self.robot_x,
                        robot_y=self.robot_y,
                        robot_heading_deg=self.robot_heading_deg,
                    )
                elif 0.0 < self.ble_right_cm < 10.0:
                    self._send_ble("-30")
                    return PathRecommendation(
                        best_angle_deg=-30.0,
                        best_label="Front-L",
                        reason=f"우측 초음파 근접 ({self.ble_right_cm:.1f}cm < 10cm) -> 좌측 보정 조향",
                        scores=scores,
                        is_stuck=False,
                        target_x=self.target_x,
                        target_y=self.target_y,
                        target_name=self.target_name,
                        dist_to_goal_m=dist_m,
                        goal_rel_angle_deg=goal_rel_angle,
                        is_goal_reached=False,
                        robot_x=self.robot_x,
                        robot_y=self.robot_y,
                        robot_heading_deg=self.robot_heading_deg,
                    )
                elif 0.0 < self.ble_left_cm < 10.0:
                    self._send_ble("30")
                    return PathRecommendation(
                        best_angle_deg=30.0,
                        best_label="Front-R",
                        reason=f"좌측 초음파 근접 ({self.ble_left_cm:.1f}cm < 10cm) -> 우측 보정 조향",
                        scores=scores,
                        is_stuck=False,
                        target_x=self.target_x,
                        target_y=self.target_y,
                        target_name=self.target_name,
                        dist_to_goal_m=dist_m,
                        goal_rel_angle_deg=goal_rel_angle,
                        is_goal_reached=False,
                        robot_x=self.robot_x,
                        robot_y=self.robot_y,
                        robot_heading_deg=self.robot_heading_deg,
                    )

                # 정상 직진 전진 주행
                chosen_angle = 0.0
                chosen_label = "Front"
                reason_msg = f"[{stage_name}] 직진 전진 주행 중 (전방 {front_clearance:.2f}m 확보)"
                self._send_ble(str(int(chosen_angle)))
                return PathRecommendation(
                    best_angle_deg=chosen_angle,
                    best_label=chosen_label,
                    reason=reason_msg,
                    scores=scores,
                    is_stuck=False,
                    target_x=self.target_x,
                    target_y=self.target_y,
                    target_name=self.target_name,
                    dist_to_goal_m=dist_m,
                    goal_rel_angle_deg=goal_rel_angle,
                    is_goal_reached=False,
                    robot_x=self.robot_x,
                    robot_y=self.robot_y,
                    robot_heading_deg=self.robot_heading_deg,
                )
            else:
                # 목표가 없는 일반 직진
                self._send_ble("0")
                return PathRecommendation(
                    best_angle_deg=0.0,
                    best_label="Front",
                    reason=f"직진 주행 중 (전방 {front_clearance:.2f}m 확보)",
                    scores=scores,
                    is_stuck=False,
                    target_x=self.target_x,
                    target_y=self.target_y,
                    target_name=self.target_name,
                    dist_to_goal_m=dist_m,
                    goal_rel_angle_deg=goal_rel_angle,
                    is_goal_reached=False,
                    robot_x=self.robot_x,
                    robot_y=self.robot_y,
                    robot_heading_deg=self.robot_heading_deg,
                )

        # ── 2. STOPPED 상태: 주행 시작 버튼을 누르지 않은 대기 상태 또는 정지 버튼 클릭 상태 ──
        elif self.state == "STOPPED":
            # [버튼 트리거 헤딩 정렬] 사용자가 '헤딩 정렬' 버튼을 클릭한 경우에만 1도 단위 정밀 정렬 수행
            if getattr(self, "aligning_heading", False):
                align_angle, align_label, target_zero_head, is_zero_aligned = self._get_zero_alignment_steering_1deg()

                if not is_zero_aligned:
                    # 1도 단위 정밀 각도 문자열 송신 (예: "12", "-5")
                    self._send_ble(str(int(align_angle)))
                    reason_msg = f"[헤딩 정렬 중 (1° 정밀)] 현재 헤딩({self.robot_heading_deg:.1f}°) -> 목표 {target_zero_head:.0f}° 정렬 중 (조향: {align_label})"
                    return PathRecommendation(
                        best_angle_deg=align_angle,
                        best_label=align_label,
                        reason=reason_msg,
                        scores=scores,
                        is_stuck=False,
                        target_x=self.target_x,
                        target_y=self.target_y,
                        target_name=self.target_name,
                        dist_to_goal_m=dist_m,
                        goal_rel_angle_deg=goal_rel_angle,
                        is_goal_reached=False,
                        robot_x=self.robot_x,
                        robot_y=self.robot_y,
                        robot_heading_deg=self.robot_heading_deg,
                    )
                else:
                    # 1도 이내 정렬 완료 시 플래그 해제 및 정지 신호 패킷 송신
                    self.aligning_heading = False
                    self._send_stop_packet(reset_odo=False)
                    print(f"\n[PathRecommender] [ALIGN COMPLETE] 헤딩 {target_zero_head:.0f}° 정렬 완료! -> STOP 대기")

            # 평상시 대기 상태에서는 BLE로 {"S-signal":"STOP", "R-signal":""} 패킷 전송
            self._send_stop_packet(reset_odo=False)

            # 양측 초음파 및 공간이 모두 30cm 미만으로 꽉 막힌 경우 유턴(180) 레이블 세팅
            if self.ble_right_cm < 30.0 and self.ble_left_cm < 30.0:
                return PathRecommendation(
                    best_angle_deg=self.UTURN_ANGLE,
                    best_label="U-Turn",
                    reason=f"좌우 공간 모두 협소 (R:{self.ble_right_cm:.1f}cm L:{self.ble_left_cm:.1f}cm) -> BLE 정지(STOP) 및 유턴 대기",
                    scores=scores,
                    is_stuck=True,
                    target_x=self.target_x,
                    target_y=self.target_y,
                    target_name=self.target_name,
                    dist_to_goal_m=dist_m,
                    goal_rel_angle_deg=goal_rel_angle,
                    is_goal_reached=False,
                    robot_x=self.robot_x,
                    robot_y=self.robot_y,
                    robot_heading_deg=self.robot_heading_deg,
                )

            # 대시보드 UI 시각화용 10도 단위 추천 각도 계산
            right_scores = [s for s in scores if s.angle_deg > 0]
            left_scores  = [s for s in scores if s.angle_deg < 0]

            right_lidar_clearance = max([s.clearance_m for s in right_scores], default=0.0)
            left_lidar_clearance  = max([s.clearance_m for s in left_scores], default=0.0)

            right_sensor_space = right_lidar_clearance * 0.6 + (self.ble_right_cm / 100.0) * 0.4
            left_sensor_space  = left_lidar_clearance * 0.6 + (self.ble_left_cm / 100.0) * 0.4

            prefer_right = right_sensor_space >= left_sensor_space

            candidate_angles = [a for a in range(10, 91, 10)] if prefer_right else [a for a in range(-10, -91, -10)]
            fallback_angles  = [a for a in range(-10, -91, -10)] if prefer_right else [a for a in range(10, 91, 10)]

            best_angle = None
            best_score = -999.0
            best_label = ""

            for angle_deg in candidate_angles:
                clearance = self._measure_clearance_with_footprint(float(angle_deg))
                if clearance >= self.ROBOT_HALF_M * 2.0:
                    score = clearance * 2.0
                    if score > best_score:
                        best_score = score
                        best_angle = float(angle_deg)
                        best_label = f"Right-{int(angle_deg)}" if angle_deg > 0 else f"Left-{int(abs(angle_deg))}"

            if best_angle is None:
                for angle_deg in fallback_angles:
                    clearance = self._measure_clearance_with_footprint(float(angle_deg))
                    if clearance >= self.ROBOT_HALF_M * 2.0:
                        score = clearance * 1.5
                        if score > best_score:
                            best_score = score
                            best_angle = float(angle_deg)
                            best_label = f"Right-{int(angle_deg)}" if angle_deg > 0 else f"Left-{int(abs(angle_deg))}"

            if best_angle is None:
                all_candidates = candidate_angles + fallback_angles
                for angle_deg in all_candidates:
                    clearance = self._measure_clearance_with_footprint(float(angle_deg))
                    if clearance > best_score:
                        best_score = clearance
                        best_angle = float(angle_deg)
                        best_label = f"Right-{int(angle_deg)}" if angle_deg > 0 else f"Left-{int(abs(angle_deg))}"

            if best_angle is None:
                best_angle = 90.0 if prefer_right else -90.0
                best_label = "Right-90" if prefer_right else "Left-90"

            self.turn_angle = best_angle
            self.turn_label = best_label

            return PathRecommendation(
                best_angle_deg=self.turn_angle,
                best_label=self.turn_label,
                reason=f"주행 시작 대기 / 정지 상태 (BLE 정지 신호 -1 전송) -> 추천: {self.turn_label}도",
                scores=scores,
                is_stuck=False,
                target_x=self.target_x,
                target_y=self.target_y,
                target_name=self.target_name,
                dist_to_goal_m=dist_m,
                goal_rel_angle_deg=goal_rel_angle,
                is_goal_reached=False,
                robot_x=self.robot_x,
                robot_y=self.robot_y,
                robot_heading_deg=self.robot_heading_deg,
            )

        # ── 3. TURNING 상태: 회피 조향 중 ──
        elif self.state == "TURNING":
            self.turn_timer -= 1

            # 회피 프레임 완료 및 전방 안전 -> 직진 상태로 평화롭게 복귀
            if self.turn_timer <= 0 and front_clearance >= self.FRONT_STOP_DIST_M:
                self.state = "FORWARD"
                self._send_ble("0")
                self._update_odometry_step(0.0)
                return PathRecommendation(
                    best_angle_deg=0.0,
                    best_label="Front",
                    reason=f"회피 완료 (전방 {front_clearance:.2f}m 확보) -> 직진 복귀",
                    scores=scores,
                    is_stuck=False,
                    target_x=self.target_x,
                    target_y=self.target_y,
                    target_name=self.target_name,
                    dist_to_goal_m=dist_m,
                    goal_rel_angle_deg=goal_rel_angle,
                    is_goal_reached=False,
                    robot_x=self.robot_x,
                    robot_y=self.robot_y,
                    robot_heading_deg=self.robot_heading_deg,
                )

            # 회피 프레임 완료했으나 전방이 여전히 막힘 -> 멈추지 않고 추가 회피 각도 지속 전송
            if self.turn_timer <= 0 and front_clearance < self.FRONT_STOP_DIST_M:
                best_s = max(scores, key=lambda s: s.clearance_m)
                self.turn_angle = best_s.angle_deg if best_s.clearance_m > 0.2 else 90.0
                self.turn_label = f"Avoid-{int(self.turn_angle)}"
                self.turn_timer = 6
                self._send_ble(str(int(self.turn_angle)))
                self._update_odometry_step(self.turn_angle)
                return PathRecommendation(
                    best_angle_deg=self.turn_angle,
                    best_label=self.turn_label,
                    reason=f"전방 재차 장애물 감지 ({front_clearance:.2f}m) -> 멈춤 없이 지속 회피 조향({self.turn_angle:+.0f}°)",
                    scores=scores,
                    is_stuck=False,
                    target_x=self.target_x,
                    target_y=self.target_y,
                    target_name=self.target_name,
                    dist_to_goal_m=dist_m,
                    goal_rel_angle_deg=goal_rel_angle,
                    is_goal_reached=False,
                    robot_x=self.robot_x,
                    robot_y=self.robot_y,
                    robot_heading_deg=self.robot_heading_deg,
                )

            # 회피 방향 송신 유지
            self._send_ble(str(int(self.turn_angle)))
            self._update_odometry_step(self.turn_angle)
            return PathRecommendation(
                best_angle_deg=self.turn_angle,
                best_label=self.turn_label,
                reason=f"{self.turn_label} 회피 주행 중 (잔여 {self.turn_timer}프레임)",
                scores=scores,
                is_stuck=False,
                target_x=self.target_x,
                target_y=self.target_y,
                target_name=self.target_name,
                dist_to_goal_m=dist_m,
                goal_rel_angle_deg=goal_rel_angle,
                is_goal_reached=False,
                robot_x=self.robot_x,
                robot_y=self.robot_y,
                robot_heading_deg=self.robot_heading_deg,
            )

        # 안전장치 폴백
        self.state = "FORWARD"
        self._update_odometry_step(0.0)
        return PathRecommendation(
            best_angle_deg=0.0,
            best_label="Front",
            reason="예외 상태 감지 -> 직진 복구",
            scores=scores,
            is_stuck=False,
            target_x=self.target_x,
            target_y=self.target_y,
            target_name=self.target_name,
            dist_to_goal_m=dist_m,
            goal_rel_angle_deg=goal_rel_angle,
            is_goal_reached=False,
            robot_x=self.robot_x,
            robot_y=self.robot_y,
            robot_heading_deg=self.robot_heading_deg,
        )

    def forward_clearance(self) -> float:
        """외부 호출용 전방 안전 거리 측정"""
        return self._measure_clearance_with_footprint(0.0)