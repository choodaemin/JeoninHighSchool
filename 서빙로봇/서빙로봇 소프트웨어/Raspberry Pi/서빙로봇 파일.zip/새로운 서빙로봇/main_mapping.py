"""
main_mapping.py
1280 x 960 2D SLAM 격자 지도 & 실시간 7방향 서빙로봇 제어 대시보드

주요 기능:
- 1280 x 960 고해상도 대시보드 GUI (오른쪽: 2D 점유 지도, 왼쪽: 실시간 위치 & 컨트롤)
- 좌측 패널:
  1. 현재 서빙로봇 위치 (X, Y) 실시간 좌표 표시
  2. Target X / Y 목표 좌표 키보드 입력창
  3. 주행 시작 (START), 초기화 (RESET), 비상정지 (EMERGENCY STOP) 버튼
- 주행 시작 시 실시간으로 서빙로봇이 이동하며 좌표값이 지속적으로 갱신됨
"""

import argparse
import time
import sys
import os
import cv2
import numpy as np
import math
from typing import Optional, List

import config
from mapper import OccupancyMap
from path_recommender import PathRecommender, PathRecommendation
from map_visualizer import MapVisualizer
from lidar_processor import LidarProcessor, LidarScan
from oak_processor import OakProcessor, OakFrame, OakObstacle
from object_classifier import ObjectClassifier, ObjectType, ClassifiedObject


def main(use_mock: bool = False, visualize: bool = True):
    print("=" * 65)
    print("  1280x960 Serving Robot SLAM & Path Recommendation System")
    print(f"  Mode: {'Simulation (Mock)' if use_mock else 'Real Hardware'}")
    print("  Controls: Mouse Click UI | Key Commands: 'q' -> Quit")
    print("=" * 65)

    # ── 1. 핵심 모듈 초기화 ──────────────────────────────────────────
    occ_map = OccupancyMap()
    recommender = PathRecommender(occ_map)
    map_vis = MapVisualizer(occ_map)
    classifier = ObjectClassifier()
    classified_objects = []

    lidar_proc = LidarProcessor(use_mock=use_mock)
    lidar_proc.start()

    oak_proc: Optional[OakProcessor] = None
    if not use_mock:
        try:
            oak_proc = OakProcessor()
            oak_proc.start()
            print("[System] OAK-D-Lite Camera Initialized.")
        except Exception as e:
            print(f"[System] OAK-D-Lite Init Failed: {e} -> LiDAR Single Mode")

    # ── 2. UI 및 상태 변수 초기화 ────────────────────────────────────
    win_name = "Serving Robot Control Dashboard (1280x960)"
    if visualize:
        cv2.namedWindow(win_name, cv2.WINDOW_AUTOSIZE)

    input_target_x_str = "2.00"
    input_target_y_str = "1.50"
    active_input: Optional[str] = None   # 'x' | 'y' | None

    is_driving = False
    is_emergency = False
    is_exit_requested = False  # UI 종료 버튼 클릭 감지 플래그
    status_msg = "SYSTEM READY"

    # ── 3. 마우스 클릭 콜백 함수 ────────────────────────────────────
    def on_mouse_click(event, x, y, flags, param):
        nonlocal input_target_x_str, input_target_y_str, active_input, is_driving, is_emergency, is_exit_requested, status_msg

        if event == cv2.EVENT_LBUTTONDOWN:
            # 1) Target X 입력창 클릭
            xx, xy, xw, xh = MapVisualizer.ROI_INPUT_X
            if xx <= x <= xx + xw and xy <= y <= xy + xh:
                active_input = 'x'
                print("[UI] ✏️ Target X 입력창 선택됨")
                return

            # 2) Target Y 입력창 클릭
            yx, yy, yw, yh = MapVisualizer.ROI_INPUT_Y
            if yx <= x <= yx + yw and yy <= y <= yy + yh:
                active_input = 'y'
                print("[UI] ✏️ Target Y 입력창 선택됨")
                return

            # 입력창 외 영역 클릭 시 포커스 해제
            active_input = None

            # 3) 주행 시작 버튼 클릭
            bx, by, bw, bh = MapVisualizer.ROI_BTN_START
            if bx <= x <= bx + bw and by <= y <= by + bh:
                try:
                    tx = float(input_target_x_str)
                    ty = float(input_target_y_str)
                    recommender.start_navigation(tx, ty, f"Target({tx:.1f},{ty:.1f})")
                    is_driving = True
                    is_emergency = False
                    status_msg = f"NAVIGATING TO ({tx:.1f}, {ty:.1f})"
                    print(f"[UI] 🚀 주행 시작: Target ({tx:.2f}, {ty:.2f})")
                except ValueError:
                    status_msg = "ERROR: INVALID NUMERIC INPUT"
                return

            # 4) [신규] 헤딩 정렬 (0°/360°) 버튼 클릭
            ax, ay, aw, ah = MapVisualizer.ROI_BTN_ALIGN_HEAD
            if ax <= x <= ax + aw and ay <= y <= ay + ah:
                recommender.start_heading_alignment()
                status_msg = "ALIGNING HEADING (0° / 360°)..."
                print("[UI] 🧭 [ALIGN HEADING] 버튼 클릭됨 -> 0°/360° 1도 단위 정렬 시작!")
                return

            # 5) 초기화 버튼 클릭
            rx_b, ry_b, rw_b, rh_b = MapVisualizer.ROI_BTN_RESET
            if rx_b <= x <= rx_b + rw_b and ry_b <= y <= ry_b + rh_b:
                recommender.reset_odometry()
                occ_map.reset()
                is_driving = False
                is_emergency = False
                input_target_x_str = "0.00"
                input_target_y_str = "0.00"
                status_msg = "SYSTEM & MAP RESET COMPLETE (RESET_ODO SENT)"
                print("[UI] 🔄 시스템 및 맵 초기화 완료 (BLE 'RESET_ODO' 전송)")
                return

            # 5) 비상정지 버튼 클릭
            ex, ey, ew, eh = MapVisualizer.ROI_BTN_STOP
            if ex <= x <= ex + ew and ey <= y <= ey + eh:
                recommender.stop_navigation()
                is_driving = False
                is_emergency = True
                status_msg = "EMERGENCY STOP ENGAGED!"
                print("[UI] 🚨 비상정지 발동!")
                return

            # 6) [신규] 시스템 종료 버튼 (QUIT SYSTEM) 클릭
            qx, qy, qw, qh = MapVisualizer.ROI_BTN_QUIT
            if qx <= x <= qx + qw and qy <= y <= qy + qh:
                is_exit_requested = True
                status_msg = "QUIT REQUESTED BY USER"
                print("[UI] 🛑 UI [QUIT SYSTEM] 종료 버튼 클릭됨 -> 즉시 시스템 종료 중...")
                return

    if visualize:
        cv2.setMouseCallback(win_name, on_mouse_click)

    # ── 4. FPS 및 메인 루프 ──────────────────────────────────────────
    target_dt = 1.0 / config.TARGET_FPS
    frame_count = 0
    fps_timer = time.time()
    fps_display = 0.0

    try:
        while True:
            t0 = time.time()

            # 센서 데이터 수집
            lidar_scan = lidar_proc.get_scan()
            oak_frame = None

            if use_mock:
                t_now = time.time()
                mock_rgb = np.zeros((400, 400, 3), dtype=np.uint8)
                cv2.rectangle(mock_rgb, (0, 0), (400, 240), (120, 100, 90), -1)
                cv2.rectangle(mock_rgb, (0, 240), (400, 400), (60, 60, 60), -1)
                oak_frame = OakFrame(
                    depth_map=np.zeros((400, 400), dtype=np.float32),
                    rgb_frame=mock_rgb,
                    obstacles=[],
                    timestamp=t_now
                )
            else:
                if oak_proc:
                    oak_frame = oak_proc.get_frame()

            # 점유 맵 업데이트
            if frame_count % 3 == 0:
                classified_objects = classifier.classify(lidar_scan, oak_frame)

            occ_map.reset()
            if lidar_scan is not None:
                occ_map.update_from_lidar(lidar_scan)
            if oak_frame:
                occ_map.update_from_oak(oak_frame)
            if classified_objects:
                _update_map_from_classified(occ_map, classified_objects)

            # 경로 추천 및 로봇 이동 시뮬레이션
            recommendation = recommender.recommend()

            # 목표 도착 체크
            if is_driving and recommendation and recommendation.is_goal_reached:
                is_driving = False
                status_msg = "GOAL ARRIVED SUCCESSFULLY!"
                print("[UI] 🎉 목표 지점 도착 완료!")

            # ── 5. 대시보드 시각화 렌더링 ───────────────────────────
            if visualize and config.DEBUG_VISUALIZE:
                dashboard_img = map_vis.render(
                    recommendation=recommendation,
                    fps=fps_display,
                    lidar_points=len(lidar_scan.points) if lidar_scan else 0,
                    input_target_x_str=input_target_x_str,
                    input_target_y_str=input_target_y_str,
                    active_input=active_input,
                    is_driving=is_driving,
                    is_emergency=is_emergency,
                    status_msg=status_msg,
                )

                cv2.imshow(win_name, dashboard_img)

                # ── 6. UI 종료 버튼 클릭, 창 닫기(X), 키보드 처리 ─────────────────────────────
                if is_exit_requested:
                    print("[System] UI [QUIT SYSTEM] 클릭 요청에 따른 시스템 종료 중...")
                    break

                key = cv2.waitKey(1) & 0xFF

                # waitKey 호출 이후 OpenCV Window 닫기(X 버튼 클릭) 감지
                try:
                    if cv2.getWindowProperty(win_name, cv2.WND_PROP_VISIBLE) < 1:
                        print("[System] GUI 창 닫기(X) 감지 -> 종료 중...")
                        break
                except Exception:
                    break

                if key == ord('q') or key == 27:  # 'q' 또는 ESC
                    print("[System] 종료 키 입력 -> 종료 중...")
                    break

                # 텍스트 입력창 키 입력 처리
                if active_input is not None and key != 255:
                    curr_str = input_target_x_str if active_input == 'x' else input_target_y_str

                    if key in (8, 127):  # Backspace
                        curr_str = curr_str[:-1]
                    elif key in (13, 10):  # Enter
                        active_input = None
                    elif 32 <= key <= 126:
                        ch = chr(key)
                        if ch in "0123456789.-":
                            if len(curr_str) < 7:
                                curr_str += ch

                    if active_input == 'x':
                        input_target_x_str = curr_str
                    elif active_input == 'y':
                        input_target_y_str = curr_str

            # FPS 측정
            frame_count += 1
            if frame_count % 15 == 0:
                now = time.time()
                fps_display = 15 / max(now - fps_timer, 1e-6)
                fps_timer = now

            elapsed = time.time() - t0
            sleep_t = max(0.0, target_dt - elapsed)
            time.sleep(sleep_t)

    except KeyboardInterrupt:
        print("\n[System] 사용자 중지 요청 (Ctrl+C)")

    finally:
        print("\n[System] 시스템 정리 및 자원 해제 중...")
        # ── [종료 1순위] BLE 프로세스를 가장 먼저 안전하게 종료 ──
        try:
            if 'recommender' in locals() and recommender and getattr(recommender, 'ble', None):
                print("[System] [1순위] BLE 프로세스 종료 중...")
                recommender.ble.stop()
                print("[System] BLE 프로세스 정상 종료 완료.")
        except Exception as e:
            print(f"[System] BLE 프로세스 종료 중 예외 (무시): {e}")

        # ── [종료 2순위] LiDAR 프로세스 종료 ──
        try:
            if 'lidar_proc' in locals() and lidar_proc:
                print("[System] [2순위] LiDAR 프로세스 종료 중...")
                lidar_proc.stop()
        except Exception:
            pass

        # ── [종료 3순위] OAK 카메라 프로세스 종료 ──
        try:
            if 'oak_proc' in locals() and oak_proc:
                print("[System] [3순위] OAK 프로세스 종료 중...")
                oak_proc.stop()
        except Exception:
            pass

        # ── [종료 4순위] OpenCV GUI 창 닫기 ──
        try:
            if visualize:
                cv2.destroyAllWindows()
        except Exception:
            pass

        print("[System] 모든 리소스 해제 완료 -> 완전히 종료됩니다.")
        os._exit(0)


def _update_map_from_classified(occ_map: OccupancyMap, classified_objects: List[ClassifiedObject]): 
    for obj in classified_objects:
        if obj.object_type in (ObjectType.PERSON, ObjectType.OBSTACLE, ObjectType.GLASS_WALL):
            rad = math.radians(obj.angle_deg)
            x_m = obj.distance_m * math.sin(rad)
            y_m = obj.distance_m * math.cos(rad)
            row, col = occ_map.world_to_cell(x_m, y_m)
            val = 0.6 if obj.object_type == ObjectType.GLASS_WALL else 1.0
            occ_map.set_cell(row, col, val)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="1280x960 Serving Robot SLAM & Path Recommendation System")
    parser.add_argument("--mock", action="store_true", help="하드웨어 없이 시뮬레이션 테스트 실행")
    parser.add_argument("--no-vis", action="store_true", help="OpenCV GUI 시각화 비활성화")
    args = parser.parse_args()

    main(use_mock=args.mock, visualize=not args.no_vis)
